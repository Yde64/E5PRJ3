/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */
#include "project.h"

void delline(int numberoflines);    //Sletter linjer i terminalen
void movecursor(char* y, char* x);  //Flytter cursor i terminalen til ønsket position
void setcolor(char color);          //Sætter ønsket tekst farve (Rød, Blå eller grøn)

