/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
//#include "project.h"
#include "LEDcontrol.h"
#include "WeightSensors_.h"
#include "UART.h"
#include "Display.h"
#include "Startknap.h"
#include "States.h"


#define LEDlength 21
#define glasvaegtp1 25 //eksempel
#define glasvaegtp2 25 //eksempel - skal testes
int glasvaegtWinner = 0;
int glasvaegtLoser = 0;
int pLoser = 0;


//WeightSensors  _WSptr = {.p1 = 0, .p2 = 0}; //WeightSensor Pointer

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    // SPIM_1_Start();
    isr_button_StartEx(isr_button);
    isr_uart_rx_StartEx(ISR_UART_rx_handler);
    UART_1_Start();
    
    WeightSensorsInit();
    // LEDctrl *ptr, rgbLED[LEDlength];
    // ptr = rgbLED;
    // LEDinit(LEDlength, ptr, 60);
    
    
    //ringLED(100,4,87,1.0,0.7);
    //pulseLED(20,100,1,1);
    
    states state = IDLE;
    
    for(;;)
    {
       
        switch(state)
        {
            
        case IDLE:
            {
                if(ButtonPushed)                //hvis startknap 
                {                               
                    state =  EVALUATING_WEIGHT; //state -> Evaluating Weight  
                }
            
                else
                {   
                    state = IDLE;               //ellers bliv her
                }
            }
            break;
           
        case GOING_IDLE :
            {
                state = IDLE;                   //state -> Idle
            }
            break;
            
        case EVALUATING_WEIGHT :
            {
                if (CompareWeight() == 1)       //hvis vægten passer
                {
                    state = READY;
                }
                else if (CompareWeight() == 2)  //hvis vægten ikke passer p1>p2
                {
                    state = ERR_NO_START;
                }
                else if (CompareWeight() == 3)  //hvis vægten ikke passer p1<p2
                {
                    state = ERR_NO_START;
                }
                else 
                state = EVALUATING_WEIGHT;
                
            }
            break;
            
        case READY :
            {
                if (ButtonPushed == 1)
                {
                    state = COUNTDOWN;
                }
                //hvis startknap -> Countdown
                
            /*  else if () //timer error = state err2
                {
                    state = ERR_NO_START;
                }
                
                */
               
                else 
                {
                    state = READY;
                }    
            }
            break;
            
        case COUNTDOWN :
            {
                /*if () timer halløj
                {
                    state = CHUG 
                }
                
            
                else
                {
                    
                }
                
                */
            }
            break;
            
        case CHUG:
            {
                if(glasvaegtp1 == readdata1()) //Her skal det erklæres hvilken af de to spillere der vinder --> sæt pLoser til enten 0(p1) eller 1(p2)
                {
                    pLoser = 1;
                    glasvaegtLoser = glasvaegtp2;
                    state = WINNER_DONE; //assign glasvaegtp1/p2 til glasvaegtLoser og glasvaegtWinner
                                        
                }
                else if (glasvaegtp2 == readdata2()) //hvis spiller2 vinder, sættes p1-data til Loser-data
                {
                    pLoser = 0;
                    glasvaegtLoser = glasvaegtp1;
                    state = WINNER_DONE;
                }
                               
            }
            break;    
            
        case WINNER_DONE:
            {
                state = EVALUATING_NEW_WEIGHT;       
            }
            break;
            
        case EVALUATING_NEW_WEIGHT :
            {
                if(glasvaegtLoser == readdataLoser(pLoser))
                {
                    state = WEIGHT_CONFIRMED;
                }
            }   
            break;
            
        case LOSER_DONE:
            {
                
            }  
            break;
        case WEIGHT_CONFIRMED:
            {
            }    
            break;
        
            
            
            
            
            
            
            
            // ------------------------------------ERR STATES---------------------------------------------------
            
            case ERR_WEIGHT:
            {
            }    
            break;
            
            case ERR_NO_START:
            {
            }    
            break;
            
            case ERR_FALSE_START:
            {
            }    
            break;
            
            case ERR_TIMEOUT:
            {
            }    
            break;
            
            case ERR_NOCHUG:
            {
            }    
            break;
            
            
        default :
            {
            }
            break;
            
        
        }

    }
}


/* [] END OF FILE */
