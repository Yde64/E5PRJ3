#include "Startknap.h"
#include "States.h"


CY_ISR(isr_button){
    ButtonPushed = 1;
       
    ButtonPushed = 0;
}