/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define Idle                    1 //Gamestates
#define Going_idle              2
#define EvaluatingWeight        3
#define Ready                   4
#define Countdown               5
#define Spiller1_done           6
#define Evaluating_new_weight   7
#define Spiller2_done           8
#define WeightConfirmed         9

#define Loserp1                 10 //Playerstates
#define Loserp2                 11
#define Winnerp1                12
#define Winnerp2                13

#define Game_Over               14 //GAME FINISHED


#define err_vaegt               15 //Errorstates
#define err_no_start            16
#define err_false_start         17
#define err_timeout             18 //err 5&6 i STM
#define err_nochug              19


/* [] END OF FILE */
