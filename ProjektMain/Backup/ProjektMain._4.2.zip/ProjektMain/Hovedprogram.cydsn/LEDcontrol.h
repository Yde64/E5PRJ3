/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */
#pragma once 

#include "project.h"
#include "stdio.h"
#include "math.h"

typedef struct LEDctrl_
{
    int red;
    int green;
    int blue;
    
    double h;
    double s;
    double v;
    
    int green1;
    int green2;
    int red1;
    int red2;
    int blue1;
    int blue2;  
}LEDctrl;

void UpdateLED();
void setrefreshrate(int Hz);


void hsv2rgb(double H, double S, double L, int LED);
void setcolorLED(double h, double s, double v, int LED);
void fillcolor(double h, double s, double v);
void pulseLED(int speed, double h, double s, double v);
void LEDinit(int LEDlength, LEDctrl *rgbLED, int Refreshrate);
void ringLED(int speed, int pulselength, double h, double s, double v);